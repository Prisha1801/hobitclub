<?php
namespace App\Http\Controllers\Api\Worker;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Worker;

class WorkerProfileController extends Controller
{
    /**
     * Update worker profile
     */
    public function update(Request $request)
    {
        $worker = auth()->user()->worker;

        $request->validate([
            'skills'         => 'array',
            'preferred_area' => 'string|nullable',
            'available_days' => 'array|nullable',
            'available_time' => 'array|nullable',
        ]);

        $worker->update($request->only([
            'skills',
            'preferred_area',
            'available_days',
            'available_time',
        ]));

        return response()->json([
            'success' => true,
            'message' => 'Profile updated',
        ]);
    }

    /**
     * Get own profile (worker + user data)
     */
    public function me()
    {
        $user = auth()->user()->load('worker');

        if (! $user->worker) {
            return response()->json([
                'success' => false,
                'message' => 'Worker profile not found',
            ], 404);
        }

        $worker = $user->worker;

        /* ----------------------------------------
        FORMAT KYC DOCUMENTS
        ----------------------------------------- */
        $documents = [];

        if (is_array($worker->id_type)) {
            foreach ($worker->id_type as $index => $type) {
                $documents[] = [
                    'type'   => $type,
                    'number' => $worker->id_number[$index] ?? null,
                    'front'  => isset($worker->id_front_path[$index])
                        ? asset('storage/' . $worker->id_front_path[$index])
                        : null,
                    'back'   => isset($worker->id_back_path[$index])
                        ? asset('storage/' . $worker->id_back_path[$index])
                        : null,
                ];
            }
        }

        return response()->json([
            'success' => true,

            /* ---------------- USER ---------------- */
            'user' => [
                'id'       => $user->id,
                'name'     => $user->name,
                'phone'    => $user->phone,
                'email'    => $user->email,

                // Services from users table
                'category_ids' => $user->category_ids,
                'service_ids'  => $user->service_ids,

                // Availability from users table
                'available_days' => $user->available_days ?? null,
                'available_time' => $user->available_time ?? null,

                'city_id' => $user->city_id,
                'zone_id' => $user->zone_id,
                'area_id' => $user->area_id,
            ],

            /* ---------------- WORKER ---------------- */
            'worker' => [
                'worker_id'      => $worker->id,
                'wallet_balance' => $worker->wallet_balance,
                'kyc_status'     => $worker->kyc_status,
            ],

            /* ---------------- KYC ---------------- */
            'documents' => $documents,

            'created_at' => $worker->created_at,
            'updated_at' => $worker->updated_at,
        ]);
    }

    public function uploadKyc(Request $request)
    {
        $worker = auth()->user()->worker;

        if (! $worker) {
            return response()->json([
                'success' => false,
                'message' => 'Worker profile not found',
            ], 404);
        }

        $request->validate([
            'id_type'   => 'required|string',
            'id_number' => 'required|string',
            'id_front'  => 'required|image|mimes:jpg,jpeg,png',
            'id_back'   => 'nullable|image|mimes:jpg,jpeg,png',
        ]);

        // Base folder: public/uploads/workers/{worker_id}
        $basePath = "uploads/workers/{$worker->id}";

        // Store files
        $frontFileName = 'id_front_' . time() . '.' . $request->file('id_front')->getClientOriginalExtension();
        $frontPath     = $request->file('id_front')->storeAs(
            $basePath,
            $frontFileName,
            'public'
        );

        $backPath = null;
        if ($request->hasFile('id_back')) {
            $backFileName = 'id_back_' . time() . '.' . $request->file('id_back')->getClientOriginalExtension();
            $backPath     = $request->file('id_back')->storeAs(
                $basePath,
                $backFileName,
                'public'
            );
        }

        // Update worker KYC data
        $worker->update([
            'id_type'       => $request->id_type,
            'id_number'     => $request->id_number,
            'id_front_path' => $frontPath,
            'id_back_path'  => $backPath,
            'kyc_status'    => 'pending',
        ]);

        return response()->json([
            'success'   => true,
            'message'   => 'KYC uploaded successfully. Waiting for approval.',
            'documents' => [
                'id_front_url' => asset('storage/' . $frontPath),
                'id_back_url'  => $backPath ? asset('storage/' . $backPath) : null,
            ],
        ]);
    }

    // public function uploaddocs(Request $request, User $user = null)
    // {
        
    //     if (auth()->user()->role === 'admin') {
    //         $worker = $user->worker;
    //     } else {
    //         $worker = auth()->user()->worker;
    //     }
    //     if (! $worker) {
    //         return response()->json([
    //             'success' => false,
    //             'message' => 'Worker profile not found',
    //         ], 404);
    //     }
    //     $request->validate([
    //         'id_type'     => 'required|array|min:1',
    //         'id_type.*'   => 'required|string',

    //         'id_number'   => 'required|array|min:1',
    //         'id_number.*' => 'required|string',

    //         'id_front'    => 'required|array|min:1',
    //         'id_front.*'  => 'required|image|mimes:jpg,jpeg,png|max:2048',

    //         'id_back'     => 'nullable|array',
    //         'id_back.*'   => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
    //     ]);

    //     $basePath = "uploads/workers/{$worker->id}";

    //     $idTypes     = [];
    //     $idNumbers   = [];
    //     $frontPaths  = [];
    //     $backPaths   = [];

    //     foreach ($request->id_type as $index => $type) {

    //         // Front image (mandatory)
    //         $frontPaths[] = $request->file('id_front')[$index]
    //             ->store($basePath, 'public');

    //         // Back image (optional)
    //         $backPaths[] = !empty($request->file('id_back')[$index])
    //             ? $request->file('id_back')[$index]->store($basePath, 'public')
    //             : null;

    //         $idTypes[]   = $type;
    //         $idNumbers[] = $request->id_number[$index];
    //     }

    //     $worker->update([
    //         'id_type'        => $idTypes,
    //         'id_number'      => $idNumbers,
    //         'id_front_path'  => $frontPaths,
    //         'id_back_path'   => $backPaths,
    //         'kyc_status'     => 'pending',
    //     ]);

    //     return response()->json([
    //         'success' => true,
    //         'message' => 'KYC documents updated successfully',
    //         'count'   => count($idTypes),
    //     ]);
    // }

    public function uploaddocs(Request $request, User $user = null)
    {
        /* ------------------------------------
        Resolve worker (admin / worker)
        ------------------------------------- */
        if (auth()->user()->role === 'admin') {
            $worker = $user?->worker;
        } else {
            $worker = auth()->user()->worker;
        }

        if (! $worker) {
            return response()->json([
                'success' => false,
                'message' => 'Worker profile not found',
            ], 404);
        }

        /* ------------------------------------
        Validation
        ------------------------------------- */
        $request->validate([
            'id_type'     => 'required|array|min:1',
            'id_type.*'   => 'required|string',

            'id_number'   => 'required|array|min:1',
            'id_number.*' => 'required|string',

            'id_front'    => 'required|array|min:1',
            'id_front.*'  => 'required|image|mimes:jpg,jpeg,png|max:2048',

            'id_back'     => 'nullable|array',
            'id_back.*'   => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);

        $basePath = "uploads/workers/{$worker->id}";

        $idTypes    = [];
        $idNumbers  = [];
        $frontPaths = [];
        $backPaths  = [];

        /* ------------------------------------
        Store documents
        ------------------------------------- */
        foreach ($request->id_type as $index => $type) {

            $safeType = str_replace(' ', '_', strtolower($type));
            $timestamp = time();

            // FRONT IMAGE (mandatory)
            $frontFile = $request->file('id_front')[$index];
            $frontFileName = "{$safeType}_front_{$timestamp}_{$index}."
                . $frontFile->getClientOriginalExtension();

            $frontPath = $frontFile->storeAs(
                $basePath,
                $frontFileName,
                'public'
            );

            // BACK IMAGE (optional)
            $backPath = null;
            if (isset($request->file('id_back')[$index])) {
                $backFile = $request->file('id_back')[$index];
                $backFileName = "{$safeType}_back_{$timestamp}_{$index}."
                    . $backFile->getClientOriginalExtension();

                $backPath = $backFile->storeAs(
                    $basePath,
                    $backFileName,
                    'public'
                );
            }

            // Collect data
            $idTypes[]    = $type;
            $idNumbers[]  = $request->id_number[$index];
            $frontPaths[] = $frontPath;
            $backPaths[]  = $backPath;
        }

        /* ------------------------------------
        Update worker
        ------------------------------------- */
        $worker->update([
            'id_type'       => $idTypes,
            'id_number'     => $idNumbers,
            'id_front_path' => $frontPaths,
            'id_back_path'  => $backPaths,
            'kyc_status'    => 'pending',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'KYC documents uploaded successfully',
            'documents_count' => count($idTypes),
        ]);
    }
}