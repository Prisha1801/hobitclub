<?php

namespace App\Http\Controllers\Api\Worker;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Worker;
use App\Models\WorkerAvailability;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class WorkerAuthController extends Controller
{
    /**
     * Create worker account and generate token
     */
    public function register(Request $request)
    {
        $request->validate([
            'name'     => 'required|string',
            'email'    => 'nullable|email|unique:users,email',
            'phone'    => 'required|string|unique:users,phone',
            'password' => 'required|min:6',

            'category_ids'   => 'required|array|min:1',
            'category_ids.*' => 'exists:service_categories,id',

            'service_ids'   => 'required|array|min:1',
            'service_ids.*' => 'exists:services,id',

            'city_id' => 'nullable|exists:cities,id',
            'zone_id' => 'nullable|exists:zones,id',
            'area_id' => 'nullable|exists:serviceable_areas,id',

            'available_dates'   => 'required|array|min:1',
            'available_dates.*' => 'date',

            'available_times'        => 'required|array|min:1',
            'available_times.*.start'=> 'required|date_format:H:i',
            'available_times.*.end'  => 'required|date_format:H:i',
        ]);

        /* --------------------------------------------
        VALIDATE SERVICE ↔ CATEGORY RELATION
        --------------------------------------------- */

        $invalidServices = Service::whereIn('id', $request->service_ids)
            ->whereNotIn('category_id', $request->category_ids)
            ->exists();

        if ($invalidServices) {
            throw ValidationException::withMessages([
                'service_ids' => 'One or more services do not belong to selected categories'
            ]);
        }

        DB::beginTransaction();

        try {
            /* --------------------------------------------
            CREATE USER
            --------------------------------------------- */

            $user = User::create([
                'name'         => $request->name,
                'email'        => $request->email,
                'phone'        => $request->phone,
                'password'     => Hash::make($request->password),
                'role'         => 'worker',
                'category_ids' => $request->category_ids,
                'service_ids'  => $request->service_ids,
                'city_id'      => $request->city_id,
                'zone_id'      => $request->zone_id,
                'area_id'      => $request->area_id,
                'is_active'    => true,
            ]);
            
            /* --------------------------------------------
            CREATE WORKER PROFILE
            --------------------------------------------- */

            $worker = Worker::create([
                'user_id'    => $user->id,
                'kyc_status' => 'pending',
            ]);
            
            WorkerAvailability::create([
                'worker_id'       => $worker->user_id,
                'available_dates' => $request->available_dates,
                'available_times' => $request->available_times,
                'status'          => true,
            ]);

            DB::commit();

            return response()->json([
                'success'   => true,
                'worker_id' => $user->id,
                'token'     => $user->createToken('worker-token')->plainTextToken,
                'message'   => 'Worker registered successfully'
            ], 201);

        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }


    public function update(Request $request, User $user = null)
    {
        /* --------------------------------------------
        WHO CAN UPDATE
        --------------------------------------------- */
        if (auth()->user()->role === 'admin') {
            $user = $user ?? abort(404, 'Worker not found');
        } else {
            $user = auth()->user();
        }

        if ($user->role !== 'worker') {
            abort(403, 'Target user is not a worker');
        }

        /* --------------------------------------------
        VALIDATION
        --------------------------------------------- */
        $request->validate([
            'name'     => 'sometimes|string',
            'email'    => 'sometimes|email|unique:users,email,' . $user->id,
            'phone'    => 'sometimes|string|unique:users,phone,' . $user->id,
            'password' => 'sometimes|min:6',

            'category_ids'   => 'sometimes|array|min:1',
            'category_ids.*' => 'exists:service_categories,id',

            'service_ids'   => 'sometimes|array|min:1',
            'service_ids.*' => 'exists:services,id',

            'city_id' => 'nullable|exists:cities,id',
            'zone_id' => 'nullable|exists:zones,id',
            'area_id' => 'nullable|exists:serviceable_areas,id',

            'available_dates'   => 'sometimes|array|min:1',
            'available_dates.*' => 'date',

            'available_times'         => 'sometimes|array|min:1',
            'available_times.*.start' => 'required_with:available_times|date_format:H:i',
            'available_times.*.end'   => 'required_with:available_times|date_format:H:i',
        ]);

        /* --------------------------------------------
        VALIDATE SERVICE ↔ CATEGORY (IF SENT)
        --------------------------------------------- */
        if ($request->has('service_ids')) {

            $categoryIds = $request->category_ids ?? $user->category_ids;

            $invalidServices = Service::whereIn('id', $request->service_ids)
                ->whereNotIn('category_id', $categoryIds)
                ->exists();

            if ($invalidServices) {
                throw ValidationException::withMessages([
                    'service_ids' => 'One or more services do not belong to selected categories'
                ]);
            }
        }

        DB::beginTransaction();

        try {
            /* --------------------------------------------
            UPDATE USER
            --------------------------------------------- */
            $updateData = $request->only([
                'name',
                'email',
                'phone',
                'category_ids',
                'service_ids',
                'city_id',
                'zone_id',
                'area_id',
            ]);

            if ($request->filled('password')) {
                $updateData['password'] = Hash::make($request->password);
            }

            $user->update($updateData);

            /* --------------------------------------------
            UPDATE AVAILABILITY (OPTIONAL)
            --------------------------------------------- */
            if ($request->has('available_dates') || $request->has('available_times')) {

                WorkerAvailability::updateOrCreate(
                    ['worker_id' => $user->worker->id],
                    [
                        'available_dates' => $request->available_dates ?? $user->availability?->available_dates,
                        'available_times' => $request->available_times ?? $user->availability?->available_times,
                        'status' => true,
                    ]
                );
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Worker updated successfully',
                'data' => $user->fresh()
            ]);

        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function destroy(User $user)
    {
        if (
            auth()->user()->role !== 'admin' &&
            auth()->id() !== $user->id
        ) {
            abort(403, 'Unauthorized');
        }

        if ($user->role !== 'worker') {
            abort(403, 'Target user is not a worker');
        }

        $user->delete();

        return response()->json([
            'success' => true,
            'message' => 'Worker deleted successfully'
        ]);
    }
}
